//Este es el archivo de arranque de nuestra aplicación (el principal)
import app from "./app.js";

app.listen(3000);

console.log("Servidor corriendo en puerto", 3000);