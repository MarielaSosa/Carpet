//En este archivo se genera la conexión a la base de datos
import pg from "pg";

//Primero creamos un objeto de conexión
export const pool = new pg.Pool({
    port:5432,
    host:"localhost",
    user:"postgres",
    password:"admin",
    database:"Carpet",
});

//Luego hacemos que se conecte
pool.on("connect", ()=>{
    console.log("Conectado a la base de datos");
});
