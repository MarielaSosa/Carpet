import { Router } from "express";

const router = Router();

// Ruta de inicio de sesión para el admin
router.post('/login', adminController.login);

// Rutas para administrar cuidadores
router.get('/cuidadores', adminController.getAllCaregivers); // listar todos los cuidadores
router.get('/cuidador/:id', adminController.getCaregiverById); // Obtener un cuidador por ID
router.delete('/cuidador/:id', adminController.deleteCaregiver); // eliminar un cuidador por ID

// Rutas para administrar clientes
router.get('/cliente', adminController.getAllClients); // listar todos los clientes
router.get('/cliente/:id', adminController.getClientById); // Obtener un cliente por ID
router.delete('/cliente/:id', adminController.deleteClient); // eliminar un cliente por ID

// Otras rutas para administrar perfiles de mascotas... -- ver si se implementa o si no
router.get('/petProfiles', adminController.getAllPetProfiles);
router.delete('/petProfiles/:id', adminController.deletePetProfile);

export default router;
