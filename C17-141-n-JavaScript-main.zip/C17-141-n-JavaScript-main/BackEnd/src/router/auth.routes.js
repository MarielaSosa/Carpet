import Router from "express-promise-router";
import { deleteCliente, profile, signin, signout, signup, updateCliente } from "../controllers/auth.controller.js"; 
import {isAuth} from "../middlewares/auth.middleware.js"
import {validateSchema} from "../middlewares/validate.middleware.js"
import {signupSchema, signinSchema} from "../schemas/auth.schema.js"

const router = Router();

router.post("/signin", validateSchema(signinSchema), signin);

router.post("/signup", validateSchema(signupSchema), signup);

router.post("/signout", signout);

router.get("/profile", isAuth, profile);

router.put("/cliente/:id", updateCliente);

router.delete("/cliente/:id", deleteCliente);

export default router; 