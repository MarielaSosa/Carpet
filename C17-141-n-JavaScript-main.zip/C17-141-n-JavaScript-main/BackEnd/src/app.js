//Desde acá nos comunicamos con el servidor, todo el código de express

import express from "express";
import morgan from "morgan";
import authRoutes from "../src/router/auth.routes.js";
import cookieParser from "cookie-parser";
import cors from "cors";

const app = express();

//Middlewares
app.use(morgan("dev")); //morgan en su configuración dev nos permite ver mensajes mas limpios en consola/terminal
app.use(cors(//cualquier página creada puede pedirle los datos al backend
{
    origin: "http://localhost:5173",
    credentials: true
}
));

app.use(cookieParser());
app.use(express.json()); //convertimos los objetos a formato de javascript
app.use(express.urlencoded({extended : false})); //para codificar los formularios html

app.get("/", (req, res) => res.json({message: "Bienvenidos a Carpet App"}));
app.use('/api', authRoutes);

//MANEJADOR DE ERRORES: Si hay algun error con las rutas, por medio de 'next' ejecutamos desde acá directamente
app.use((err, req, res, next) => {
    res.status(500).json({
        status: "error",
        message: err.message
    }); //el ststus 500 es un error crítico a nivel de sistema
});

export default app;
