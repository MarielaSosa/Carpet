import { pool } from "../db.js";
import bcrypt from 'bcrypt'; //importamos bcrypt
import { createAccessToken } from "../libs/jwt.js";
import md5 from "md5";

export const signin = async (req, res) => {
    const { email, pass } = req.body;

    const result = await pool.query("SELECT * FROM cliente WHERE email = $1", [email]);

    if (result.rowCount === 0) {
        return res.status(400).json({ message: "El correo no esta registrado" });
    }

    const validPassword = await bcrypt.compare(pass, result.rows[0].pass);

    if (!validPassword) {
        return res.status(400).json({ message: "La contraseña es incorrecta" });
    }

    const token = await createAccessToken({ id: result.rows[0].id });
    console.log(result);
    res.cookie("token", token, {
        //httpOnly: true,
        //secure: true,
        sameSite: "none",
        maxAge: 60 * 60 * 24 * 1000,
    }); // 1day})
    
    //console.log('inicio de sesion correcto')

    return res.json(result.rows[0]);
};

export const signup = async (req, res, next) => {
    const { nombre, email, pass } = req.body;

    try {
        //encriptamos el password antes de que lo ingrese a la bd
        const hashedPassword = await bcrypt.hash(pass, 10); //se repite entre 10 y 15 veces el algoritmo
        md5(email);
        const gravatar = "https://gravatar.com/avatar/" + md5(email); //guarda el hash en la constante
        //console.log(hashedPassword);


        const result = await pool.query("INSERT INTO cliente (nombre, email, pass, gravatar) VALUES ($1, $2, $3, $4) RETURNING *", [nombre, email, hashedPassword, gravatar]); //guardamos la contraseña ya hasheada

        const token = await createAccessToken({ id: result.rows[0].id });
        console.log(result);
        res.cookie("token", token, {
            //httpOnly: true,
            //secure: true,
            sameSite: "none",
            maxAge: 60 * 60 * 24 * 1000,
        }); // 1day})
        return res.json(result.rows[0]);
    } catch (error) {
        if (error.code === "23505") {
            return res.status(400).json({ message: "El correo ya esta registrado" });
        }
        next(error);

    }
};
export const signout = (req, res) => {
    res.clearCookie("token");
    return res.json({ message: "Sesion cerrada" });
};


export const profile = async (req, res) => {
    const result = await pool.query('SELECT * FROM cliente WHERE id = $1', [req.usuarioId]);
    return res.json(result.rows[0]);
};


export const updateCliente = async (req, res) => {
    const id = parseInt(req.params.id);
    
    const { nombre, email } = req.body;
  
    const { rows } = await pool.query("UPDATE cliente SET nombre = $1, email = $2 WHERE id = $3 RETURNING *", [nombre, email, id]);
  
    console.log('datos actualizados correctamente');
    return res.json(rows[0]);
  };
  
  export const deleteCliente = async (req, res) => {
    const id = parseInt(req.params.id);
    const { rowCount } = await pool.query("DELETE FROM cliente where id = $1", [id,]);
  
    if (rowCount === 0) {
      return res.status(404).json({ message: "No se encontró el cliente con el ID " + id });
    }
  
    return res.sendStatus(204);
}