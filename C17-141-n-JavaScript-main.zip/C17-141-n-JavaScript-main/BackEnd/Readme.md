BIENVENIDOS AL BACKEND DE *CARPET APP*
---

![REGISTRAMOS UN CLIENTE](/BackEnd/images/readme_img.png)

<details>
<summary> ¿Qué necesito instalar?</summary> <br>

- Descargar visual studio code (o algun editor de código que nos permita instalar extensiones para hacer las pruebas). **Link de descarga**: [Visual Studio Code](https://code.visualstudio.com/)

<br>

- Descargar e instalar git (necesario para clonar el repositorio a nuestra carpeta local). **Link de descarga**: [Git](https://git-scm.com/downloads)

<br>

- Instalar nodejs (este entorno de ejecución nos permite correr código javaScript del lado del servidor).
**Link de descarga**: [Node JS](https://nodejs.org/en)

<br>

- Instalar postgreSQL (para hacer backup de la base de datos del proyecto y generar nuevos usuarios/clientes).
**Link de descarga**: [PostgreSQL](https://www.postgresql.org/download/)

<br>

- Instalar en visual studio code la extensión de *Thunder Client* (para hacer las solicitudes get y post con los datos del servidor).
**Link de descarga**: [Thunder Client - Extension for VSC](https://www.thunderclient.com/)
<br>

</details>

<hr>

<details>

<summary> ¿Cómo arrancar el proyecto?</summary> <br>

- Primero vamos a nuestra pc en la ubicación que querramos (por ejemplo, el escritorio).

<br>

- Abrimos una terminal de windows o la shell de git en esa ubicación haciendo click derecho con el mouase y vamos a tipear el siguiente comando de git junto a la url de nuestro repositorio remoto en github

<br>

`git clone https://github.com/No-Country/C17-141-n-JavaScript.git`

<br> 

- Ahora vamos a instalar todas las dependencias necesarias para que nuestro proyecto funcione (son las que se encuentran en el archivo package.json que se vé en la raíz del mismo). <br>Para eso, scribimos en la terminal que tenemos abierta, el siguiente comando:
`npm i`

<br>

- Esperamos mientras todo se intala y cuando eso suceda, ejecutamos el siguiente comando en la terminal para levantar el proyecto: `npm run dev`

<br>

- Vamos a ver el mensaje del servidor corriendo en nuestro localhost:3000 asi que nos dirigimos al navegador que estamos utilizando (en este caso es chrome) y veremos a ver el mensaje de buienvenida a nuestro proyecto de **Carpet App**

![localhost](/BackEnd/images/localhost.png)

</details>

<hr>

<details>
<summary>¿Cómo cargar datos en la base de datos?</summary> <br>

- Abrimos la extensión de *Thunder client* en Visual Studio Code y seleccionamos 'new request' para generar una nueva solicitud (sea get o post).

<br>

- Nos dirigimos a la url desde donde nos vamos a conectar para traer los datos, en este caso es ``localhost:3000``

<br>
<details>
<summary>SIGNUP - REGISTRO DE UN CLIENTE</summary>

```PARA DAR DE ALTA UN CLIENTE EN NUESTRA BD - RUTA SIGNUP```
---


1. Tipeamos la siguiente ruta: `localhost:3000/api/signup`colocando 'POST' en el mètodo de la solicitud para mandar información hacia nuestro servidor.

<br>

2. En la parte del cuerpo de la petición, vamos a la parte de *BODY* y colocamos en formato json los datos que vamos a cargar utilizando el par *'key-value'* y siempre entre comillas dobles " ".

<br>

3. En la parte de la *response* o respuesta veremos los datos de carga del nuevo usuario y en el caso que el email (campo que está configurado para ser único, es decir que se permite un único registro por cliente) ya se encuentre registrado, veremos un mensaje como el que se vé de 'correo ya registrado'.

![REGISTRAMOS UN CLIENTE](/BackEnd/images/signup.png)

</details>

<br>

<details>
<summary>SIGNIN - INICIAR SESIÓN</summary>

```PARA EL INICIO DE SESIÓN DE UN CLIENTE - RUTA SIGNIN```
---

1. Colocamos en la ruta la siguiente dirección: `localhost:3000/api/signin` utilizando nuevamente el método 'POST' en la solicitud para enviar esta información al servidor.

<br>

2. En el body de nuestra solicitud tipeamos en formato json tanto el nombre del cliente que va a iniciar sesión como su contraseña. Al estar ya logueado, el sistema le va a permitir iniciar sesión.

<br>

3. Vamos a ver en la parte de response (respuesta) la devolución del sistema con los datos que el cliente ingresó al registrarse en nuestra plataforma.

<br>

4. En la parte de la terminal podemos ver el registro del cliente con su contraseña hasheada (encriptada). Recordar que por fines ético, las contraseñas deben guardarse en nuestra base de datos así y el algoritmo compara luego ese 'hash' cuando el cliente tipea su contraseña para el inicio de sesión.

![INICIO DE SESIÓN DE UN CLIENTE](/BackEnd/images/signin.png)

</details>

<br>


<details>
<summary>PROFILE - VER PERFIL DE CLIENTE</summary>

```VER PERFIL REGISTRADO DE UN CLIENTE - RUTA PROFILE```
---

1. Cambiamos la ruta para iniciar nuestra petición a: `localhost:3000/api/profite` 
En este caso, utilizamos el mètodo 'GET' para traer la información del perfil asociado al cliente.

<br>

2. En el cuerpo de la petición y siempre en formato json dejamos los datos del cliente con su email y contraseña. Damos click al botón de 'send' y esperamos que nuestro servidor responda.

<br>

3. Si los datos son correctos, veremos la información de perfil vinculada a nuestro cliente, en este caso, su id, su nombre, email y contraseña que son los que utilizó para registrarse en nuestra plataforma.

![INICIO DE SESIÓN DE UN CLIENTE](/BackEnd/images/profile.png)

</details>

<br>

<details>
<summary>SIGNOUT - CERRAR SESIÓN</summary>

```PARA EL CIERRE DE SESIÓN DE UN CLIENTE - RUTA SIGNOUT```
---

1. Cambiamos la ruta en localhost a `localhost:3000/api/signout` eligiendo otra vez el método 'POST' para enviar la solicitud al servidor.

<br>

2. Damos click en send para iniciar nuestra petición al servidor.

<br>

3. Veremos en la sección de response - respuesta, el mensaje que indica que la sesión finalizó correctamente y el cliente pudo salir de nuestro sistema.

![INICIO DE SESIÓN DE UN CLIENTE](/BackEnd/images/signout.png)

</details>

</details>